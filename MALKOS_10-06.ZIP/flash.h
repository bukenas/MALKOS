

void write_2_flash_string(unsigned char *data, unsigned long address, unsigned char charnumber);
//void read_from_flash_strings(unsigned char i, unsigned char kiek);
//void write_2_flash_buffer(unsigned char *data, unsigned short address, unsigned char floatsnumber);